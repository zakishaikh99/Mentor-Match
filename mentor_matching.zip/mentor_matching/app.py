from flask import Flask, render_template, request, redirect, session
from pymongo import MongoClient

app = Flask(__name__)
app.secret_key = "secret123"

# 🔗 MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client["mentor_system"]
users_col = db["users"]


# 🏠 HOME
@app.route('/')
def home():
    return render_template("index.html")


# 🔐 LOGIN
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = users_col.find_one({
            "username": username,
            "password": password
        })

        if user:
            session['user'] = {
                "username": user['username'],
                "role": user['role'],
                "subject": user.get('subject'),
                "bio": user.get('bio'),
                "email": user.get('email')
            }

            # 🔥 Role redirect
            if user['role'] == 'admin':
                return redirect('/admin')
            elif user['role'] == 'mentor':
                return redirect('/mentor')
            else:
                return redirect('/mentee')

        return "Invalid Credentials ❌"

    return render_template("login.html")


# 📝 REGISTER
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':

        new_user = {
            "username": request.form['username'],
            "password": request.form['password'],
            "role": request.form['role'],
            "subject": request.form['subject'],
            "bio": request.form['bio'],
            "email": request.form['email']
        }

        users_col.insert_one(new_user)

        return redirect('/login')

    return render_template("register.html")


# 👨‍💼 ADMIN
@app.route('/admin')
def admin():
    if 'user' not in session or session['user']['role'] != 'admin':
        return redirect('/login')

    users = list(users_col.find({}, {"_id": 0}))
    return render_template("admin.html", users=users)


# ❌ DELETE USER
@app.route('/delete/<username>')
def delete_user(username):
    users_col.delete_one({"username": username})
    return redirect('/admin')


# 👨‍🏫 MENTOR
@app.route('/mentor')
def mentor():
    if 'user' not in session or session['user']['role'] != 'mentor':
        return redirect('/login')

    return render_template("mentor.html", user=session['user'])


# 🎓 MENTEE
@app.route('/mentee')
def mentee():
    if 'user' not in session or session['user']['role'] != 'mentee':
        return redirect('/login')

    mentors = list(users_col.find({"role": "mentor"}, {"_id": 0}))

    return render_template("mentee.html", mentors=mentors, user=session['user'])


# 🚪 LOGOUT
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')


# ▶️ RUN
if __name__ == "__main__":
    app.run(debug=True)